"""
ZoneWise Configuration
Loads environment variables and application settings
"""

from pydantic_settings import BaseSettings
from pydantic import Field
from typing import Optional
import os


class Settings(BaseSettings):
    """Application settings loaded from environment variables"""
    
    # Application
    APP_NAME: str = "ZoneWise AI Chatbot"
    APP_VERSION: str = "1.0.0"
    ENVIRONMENT: str = Field(default="development")  # development, staging, production
    DEBUG: bool = Field(default=True)
    
    # Server
    HOST: str = Field(default="0.0.0.0")
    PORT: int = Field(default=8000)
    
    # Supabase
    SUPABASE_URL: str = Field(..., description="Supabase project URL")
    SUPABASE_ANON_KEY: str = Field(..., description="Supabase anon/public key")
    SUPABASE_SERVICE_KEY: str = Field(..., description="Supabase service role key (PRIVATE)")
    
    # AI/ML APIs
    GEMINI_API_KEY: str = Field(..., description="Google Gemini API key")
    ANTHROPIC_API_KEY: Optional[str] = Field(default=None, description="Anthropic Claude API key")
    OPENAI_API_KEY: str = Field(..., description="OpenAI API key for embeddings")
    
    # Model Configuration
    PRIMARY_MODEL: str = Field(default="gemini-2.0-flash-exp")  # Gemini 2.5 Flash
    BACKUP_MODEL: str = Field(default="claude-sonnet-4-20250514")  # Claude Sonnet 4.5
    EMBEDDING_MODEL: str = Field(default="text-embedding-3-small")
    
    # Chatbot Parameters
    MAX_CONVERSATION_HISTORY: int = Field(default=10, description="Max messages to keep in context")
    INTENT_CONFIDENCE_THRESHOLD: float = Field(default=0.7, description="Min confidence for intent")
    ENTITY_CONFIDENCE_THRESHOLD: float = Field(default=0.6, description="Min confidence for entities")
    RAG_SIMILARITY_THRESHOLD: float = Field(default=0.7, description="Min similarity for RAG retrieval")
    RAG_MAX_RESULTS: int = Field(default=5, description="Max documents to retrieve")
    
    # Response Generation
    RESPONSE_TEMPERATURE: float = Field(default=0.3, description="LLM temperature (0.0-1.0)")
    RESPONSE_MAX_TOKENS: int = Field(default=1000, description="Max tokens in response")
    RESPONSE_TIMEOUT: int = Field(default=30, description="Max seconds for response generation")
    
    # Rate Limiting
    FREE_TIER_CONVERSATIONS_PER_MONTH: int = Field(default=5)
    BASIC_TIER_CONVERSATIONS_PER_MONTH: int = Field(default=-1, description="-1 = unlimited")
    
    # CORS
    CORS_ORIGINS: list[str] = Field(
        default=[
            "http://localhost:3000",
            "http://localhost:5173",
            "https://zonewise.pages.dev",  # Cloudflare Pages
        ]
    )
    
    # Logging
    LOG_LEVEL: str = Field(default="INFO")  # DEBUG, INFO, WARNING, ERROR
    SENTRY_DSN: Optional[str] = Field(default=None, description="Sentry error tracking")
    
    # Brevard County Specific
    DEFAULT_JURISDICTION: str = Field(default="Melbourne")
    BREVARD_JURISDICTIONS: list[str] = Field(
        default=[
            "Unincorporated Brevard County",
            "Melbourne",
            "Palm Bay",
            "Titusville",
            "Cocoa",
            "Cocoa Beach",
            "Satellite Beach",
            "Indialantic",
            "Melbourne Beach",
            "West Melbourne",
            "Rockledge",
            "Cape Canaveral",
            "Malabar",
            "Grant-Valkaria",
            "Palm Shores",
            "Melbourne Village",
            "Indian Harbour Beach",
        ]
    )
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = True


# Intent types
INTENT_TYPES = {
    "feasibility": {
        "description": "User asks if something is allowed",
        "examples": [
            "Can I build apartments?",
            "Is duplex allowed in R-1?",
            "Am I able to add a garage apartment?"
        ],
        "confidence_threshold": 0.85
    },
    "calculation": {
        "description": "User wants quantitative analysis",
        "examples": [
            "How much can I build?",
            "What's the maximum square footage?",
            "How many units fit on my lot?"
        ],
        "confidence_threshold": 0.80
    },
    "comparison": {
        "description": "User wants to compare options",
        "examples": [
            "What's the difference between R-1 and R-1A?",
            "R-2 vs R-3 zoning?",
            "Which zone allows commercial?"
        ],
        "confidence_threshold": 0.80
    },
    "process": {
        "description": "User needs procedural guidance",
        "examples": [
            "How do I get a variance?",
            "What's the permit process?",
            "Who do I contact about rezoning?"
        ],
        "confidence_threshold": 0.75
    },
    "research": {
        "description": "User wants to discover options",
        "examples": [
            "Find properties where I can build 4 units",
            "Show me all R-2 parcels in Melbourne",
            "What lots allow commercial use?"
        ],
        "confidence_threshold": 0.70
    },
    "definition": {
        "description": "User needs education/explanation",
        "examples": [
            "What does FAR mean?",
            "Explain setbacks",
            "What is conditional use permit?"
        ],
        "confidence_threshold": 0.90
    }
}

# Entity types
ENTITY_TYPES = {
    "address": {
        "regex": [
            r'\d+\s+[A-Za-z\s]+(?:Street|St|Road|Rd|Avenue|Ave|Boulevard|Blvd|Lane|Ln|Drive|Dr|Way|Court|Ct|Circle|Cir)',
            r'\d+\s+[A-Za-z\s]+,\s*[A-Za-z\s]+,\s*FL'
        ],
        "examples": ["123 Ocean Ave", "456 Palm Bay Rd, Melbourne, FL"]
    },
    "zoning_code": {
        "regex": [r'R-\d+[A-Z]?', r'C-\d+', r'I-\d+', r'PUD', r'M-\d+'],
        "examples": ["R-1", "R-1A", "C-2", "PUD", "I-1"]
    },
    "use_type": {
        "keywords": {
            "residential": ["apartment", "duplex", "single-family", "multifamily", "ADU", "garage apartment", "townhouse", "condo"],
            "commercial": ["restaurant", "office", "retail", "store", "shop", "hotel", "motel"],
            "mixed-use": ["mixed-use", "live-work"],
            "industrial": ["warehouse", "manufacturing", "distribution", "factory"]
        }
    },
    "quantity": {
        "regex": [
            r'(\d{1,3}(?:,\d{3})*)\s*(?:SF|square feet|feet|ft)',
            r'(\d+)\s*units?',
            r'(\d+)\s*acres?'
        ],
        "examples": ["10,000 SF", "4 units", "2 acres"]
    }
}

# Zoning terminology glossary (for educational mode)
ZONING_GLOSSARY = {
    "FAR": {
        "full_name": "Floor Area Ratio",
        "definition": "The ratio of a building's total floor area to the lot size.",
        "example": "On a 10,000 SF lot with FAR = 0.5: Maximum building = 10,000 × 0.5 = 5,000 SF total (could be 5,000 SF single-story OR 2,500 SF two-story).",
        "reference": "Melbourne LDC Section 20.03"
    },
    "setback": {
        "full_name": "Setback",
        "definition": "The minimum required distance between a building and the property line.",
        "example": "A 25-foot front setback means your building must be at least 25 feet from the front property line.",
        "reference": "Brevard County Code Chapter 62"
    },
    "ADU": {
        "full_name": "Accessory Dwelling Unit",
        "definition": "A secondary dwelling on a single-family lot, such as a garage apartment or granny flat.",
        "example": "Most Brevard jurisdictions allow ADUs with restrictions: typically 800 SF max and require owner-occupancy.",
        "reference": "Florida Statute 163.31771"
    },
    "CUP": {
        "full_name": "Conditional Use Permit",
        "definition": "A special approval required for certain uses that may be appropriate in a zone but require review to ensure compatibility.",
        "example": "Building a church in R-1 requires a CUP with public hearing and approval by planning board.",
        "reference": None
    },
    "by-right": {
        "full_name": "By-Right Use",
        "definition": "A use that is automatically permitted in a zoning district without requiring special approval or public hearing.",
        "example": "Single-family homes are by-right in R-1 zoning. You still need building permits, but no zoning variance.",
        "reference": None
    },
    "variance": {
        "full_name": "Variance",
        "definition": "Permission to deviate from zoning requirements due to unique hardship related to the property.",
        "example": "If your lot is oddly shaped and can't meet the 25-foot setback, you might apply for a variance to reduce it to 20 feet.",
        "reference": None
    }
}

# Create global settings instance
settings = Settings()
