"""
ZoneWise Data Models
Pydantic models for type safety and validation
"""

from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime
from uuid import UUID, uuid4


# ============================================================================
# CHATBOT STATE (LangGraph State)
# ============================================================================

class ChatbotState(BaseModel):
    """
    LangGraph state for chatbot workflow
    Passed between nodes and updated throughout conversation
    """
    # Input
    user_message: str = Field(..., description="User's input message")
    session_id: str = Field(..., description="Conversation session ID")
    user_id: Optional[str] = Field(default=None, description="Authenticated user ID")
    
    # Context
    conversation_history: List[Dict[str, str]] = Field(
        default_factory=list,
        description="Previous messages [{role, content}]"
    )
    current_property: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Currently discussed property details"
    )
    
    # Processing
    intent: Optional[str] = Field(default=None, description="Classified intent type")
    intent_confidence: Optional[float] = Field(default=None, description="Intent confidence score")
    entities: Dict[str, Any] = Field(default_factory=dict, description="Extracted entities")
    entity_confidence: Dict[str, float] = Field(default_factory=dict, description="Entity confidence scores")
    
    # Knowledge
    knowledge_retrieved: List[Dict[str, Any]] = Field(
        default_factory=list,
        description="Retrieved knowledge from RAG"
    )
    zoning_data: Optional[Dict[str, Any]] = Field(
        default=None,
        description="Structured zoning data"
    )
    
    # Output
    response: Optional[str] = Field(default=None, description="AI-generated response")
    suggestions: List[str] = Field(default_factory=list, description="Follow-up action suggestions")
    confidence: Optional[float] = Field(default=None, description="Overall response confidence")
    
    # Metadata
    response_time_ms: Optional[int] = Field(default=None, description="Total response time")
    model_used: Optional[str] = Field(default=None, description="LLM model used")
    error: Optional[str] = Field(default=None, description="Error message if any")


# ============================================================================
# API REQUEST/RESPONSE MODELS
# ============================================================================

class ChatRequest(BaseModel):
    """Request body for /api/v1/chat endpoint"""
    message: str = Field(..., min_length=1, max_length=2000, description="User message")
    session_id: str = Field(..., description="Conversation session ID")
    context: Optional[Dict[str, Any]] = Field(default=None, description="Additional context")
    
    class Config:
        json_schema_extra = {
            "example": {
                "message": "Can I build apartments in Melbourne?",
                "session_id": "session_12345",
                "context": {}
            }
        }


class ChatResponse(BaseModel):
    """Response body for /api/v1/chat endpoint"""
    response: str = Field(..., description="AI-generated response")
    suggestions: List[str] = Field(default_factory=list, description="Follow-up suggestions")
    confidence: float = Field(..., ge=0.0, le=1.0, description="Response confidence")
    intent: Optional[str] = Field(default=None, description="Classified user intent")
    entities: Dict[str, Any] = Field(default_factory=dict, description="Extracted entities")
    response_time_ms: int = Field(..., description="Response time in milliseconds")
    session_id: str = Field(..., description="Session ID")
    
    class Config:
        json_schema_extra = {
            "example": {
                "response": "Yes, apartments are allowed in Melbourne! They're permitted in R-2, R-3, and certain commercial zones. To give you specific details, I'd need to know your property address. Do you have a specific location in mind?",
                "suggestions": [
                    "Provide property address for analysis",
                    "Learn about R-2 zoning requirements",
                    "View apartment zoning map"
                ],
                "confidence": 0.92,
                "intent": "feasibility",
                "entities": {
                    "location": "Melbourne",
                    "use_type": "apartments"
                },
                "response_time_ms": 1850,
                "session_id": "session_12345"
            }
        }


# ============================================================================
# DATABASE MODELS (Supabase)
# ============================================================================

class ConversationDB(BaseModel):
    """Chatbot conversation record"""
    id: UUID = Field(default_factory=uuid4)
    user_id: Optional[UUID] = None
    session_id: str
    started_at: datetime = Field(default_factory=datetime.utcnow)
    last_message_at: datetime = Field(default_factory=datetime.utcnow)
    message_count: int = 0
    conversation_status: str = "active"  # active, completed, abandoned
    user_satisfaction: Optional[int] = None  # 1-5 rating
    created_at: datetime = Field(default_factory=datetime.utcnow)


class MessageDB(BaseModel):
    """Chatbot message record"""
    id: UUID = Field(default_factory=uuid4)
    conversation_id: UUID
    role: str  # 'user' or 'assistant'
    content: str
    intent: Optional[str] = None
    entities: Optional[Dict[str, Any]] = None
    context: Optional[Dict[str, Any]] = None
    response_time_ms: Optional[int] = None
    confidence_score: Optional[float] = None
    thumbs_up: Optional[bool] = None
    thumbs_down: Optional[bool] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)


class IntentDB(BaseModel):
    """Intent classification tracking"""
    id: UUID = Field(default_factory=uuid4)
    intent_type: str
    user_query: str
    classified_intent: str
    confidence: float
    correct_classification: Optional[bool] = None
    message_id: Optional[UUID] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)


class EntityDB(BaseModel):
    """Entity extraction tracking"""
    id: UUID = Field(default_factory=uuid4)
    message_id: UUID
    entity_type: str
    entity_value: str
    confidence: float
    correct_extraction: Optional[bool] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)


class FeedbackDB(BaseModel):
    """User feedback"""
    id: UUID = Field(default_factory=uuid4)
    message_id: Optional[UUID] = None
    conversation_id: Optional[UUID] = None
    feedback_type: str  # thumbs_up, thumbs_down, report, suggestion
    feedback_text: Optional[str] = None
    user_id: Optional[UUID] = None
    reviewed: bool = False
    action_taken: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)


# ============================================================================
# ZONING DATA MODELS
# ============================================================================

class ZoningDistrict(BaseModel):
    """Zoning district information"""
    id: UUID
    jurisdiction_id: UUID
    code: str
    name: str
    description: Optional[str] = None
    ordinance_section: Optional[str] = None


class AllowedUse(BaseModel):
    """Allowed use in a zoning district"""
    id: UUID
    zoning_district_id: UUID
    use_name: str
    use_type: str  # by-right, conditional, prohibited
    conditions: Optional[List[str]] = None
    ordinance_section: Optional[str] = None


class DimensionalStandard(BaseModel):
    """Dimensional standards for a zoning district"""
    id: UUID
    zoning_district_id: UUID
    min_lot_size: Optional[int] = None  # SF
    setback_front: Optional[float] = None  # feet
    setback_side: Optional[float] = None
    setback_rear: Optional[float] = None
    max_height: Optional[float] = None
    max_lot_coverage: Optional[float] = None  # percentage
    max_far: Optional[float] = None


class Parcel(BaseModel):
    """Property parcel information"""
    id: UUID
    jurisdiction_id: UUID
    parcel_id: str
    address: Optional[str] = None
    zoning_district_id: Optional[UUID] = None
    owner_name: Optional[str] = None
    square_footage: Optional[int] = None


# ============================================================================
# KNOWLEDGE BASE MODELS
# ============================================================================

class KnowledgeEntry(BaseModel):
    """Knowledge base entry for RAG"""
    id: UUID = Field(default_factory=uuid4)
    content_type: str  # ordinance, faq, definition
    question: Optional[str] = None
    answer: str
    source_reference: Optional[str] = None
    usage_count: int = 0
    last_used: Optional[datetime] = None


class OrdinanceContent(BaseModel):
    """Ordinance content for semantic search"""
    id: UUID
    jurisdiction_id: UUID
    section_number: str
    section_title: Optional[str] = None
    content: str
    metadata: Optional[Dict[str, Any]] = None


# ============================================================================
# UTILITY MODELS
# ============================================================================

class IntentClassificationResult(BaseModel):
    """Result of intent classification"""
    intent: str
    confidence: float
    reasoning: Optional[str] = None


class EntityExtractionResult(BaseModel):
    """Result of entity extraction"""
    entities: Dict[str, Any]
    confidence: Dict[str, float]


class KnowledgeRetrievalResult(BaseModel):
    """Result of knowledge retrieval"""
    documents: List[Dict[str, Any]]
    confidence: float
    sources: List[str]
