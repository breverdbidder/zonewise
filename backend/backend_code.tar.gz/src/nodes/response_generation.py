"""
Response Generation Node
Generates natural language responses using Gemini 2.5 Flash
"""

import json
import google.generativeai as genai
from typing import Dict, Any
import structlog

from src.models import ChatbotState
from config.settings import settings, ZONING_GLOSSARY

logger = structlog.get_logger()

# Configure Gemini
genai.configure(api_key=settings.GEMINI_API_KEY)
model = genai.GenerativeModel(settings.PRIMARY_MODEL)


async def generate_response_node(state: ChatbotState) -> Dict[str, Any]:
    """
    Generate natural language response based on:
    - User message
    - Classified intent
    - Extracted entities
    - Retrieved knowledge
    - Conversation history
    
    Args:
        state: Current chatbot state with all context
        
    Returns:
        Updated state with response and suggestions
    """
    logger.info(
        "response_generation_start",
        intent=state.intent,
        entities=state.entities,
        knowledge_count=len(state.knowledge_retrieved)
    )
    
    try:
        # ========================================
        # 1. BUILD CONTEXT FOR LLM
        # ========================================
        
        # Format conversation history
        history_str = ""
        if state.conversation_history:
            history_str = "\n".join([
                f"{msg['role'].capitalize()}: {msg['content']}"
                for msg in state.conversation_history[-5:]  # Last 5 messages
            ])
        
        # Format knowledge
        knowledge_str = ""
        if state.knowledge_retrieved:
            knowledge_items = []
            for k in state.knowledge_retrieved:
                k_type = k.get('type')
                
                if k_type == 'faq':
                    knowledge_items.append(
                        f"FAQ: Q: {k['question']}\nA: {k['answer']}\n"
                        f"Source: {k.get('source', 'Internal')}"
                    )
                
                elif k_type == 'zoning_district':
                    zd = k['data']
                    knowledge_items.append(
                        f"Zoning District: {zd['code']} - {zd['name']}\n"
                        f"Description: {zd.get('description', 'No description')}"
                    )
                    
                    # Add allowed uses if present
                    if zd.get('allowed_uses'):
                        uses = zd['allowed_uses']
                        by_right = [u['use_name'] for u in uses if u['use_type'] == 'by-right']
                        conditional = [u['use_name'] for u in uses if u['use_type'] == 'conditional']
                        
                        if by_right:
                            knowledge_items.append(f"By-right uses: {', '.join(by_right)}")
                        if conditional:
                            knowledge_items.append(f"Conditional uses: {', '.join(conditional)}")
                
                elif k_type == 'allowed_use':
                    use = k['data']
                    conditions_str = ""
                    if use.get('conditions'):
                        conditions_str = f"\nConditions: {'; '.join(use['conditions'])}"
                    
                    knowledge_items.append(
                        f"Use: {use['use_name']} - {use['use_type']}{conditions_str}"
                    )
                
                elif k_type == 'parcel':
                    parcel = k['data']
                    zoning_info = parcel.get('zoning_districts', {})
                    knowledge_items.append(
                        f"Property: {parcel.get('address')}\n"
                        f"Parcel ID: {parcel.get('parcel_id')}\n"
                        f"Zoning: {zoning_info.get('code')} - {zoning_info.get('name')}\n"
                        f"Lot Size: {parcel.get('square_footage', 'Unknown')} SF"
                    )
            
            knowledge_str = "\n\n".join(knowledge_items)
        
        # Check if user is asking for definition
        needs_definition = state.intent == "definition"
        definition_term = None
        
        if needs_definition:
            # Check if term is in glossary
            message_upper = state.user_message.upper()
            for term in ZONING_GLOSSARY.keys():
                if term in message_upper:
                    definition_term = term
                    glossary_entry = ZONING_GLOSSARY[term]
                    knowledge_str += f"\n\nDEFINITION - {term}:\n"
                    knowledge_str += f"Full Name: {glossary_entry['full_name']}\n"
                    knowledge_str += f"Definition: {glossary_entry['definition']}\n"
                    knowledge_str += f"Example: {glossary_entry['example']}\n"
                    if glossary_entry.get('reference'):
                        knowledge_str += f"Reference: {glossary_entry['reference']}\n"
                    break
        
        # ========================================
        # 2. BUILD RESPONSE GENERATION PROMPT
        # ========================================
        
        prompt = f"""
You are ZoneWise AI, a friendly and helpful zoning expert for Brevard County, Florida.

CONTEXT:
User Intent: {state.intent}
Extracted Entities: {json.dumps(state.entities, indent=2)}

{f"Conversation History:{history_str}" if history_str else "No prior conversation."}

KNOWLEDGE BASE:
{knowledge_str if knowledge_str else "No specific knowledge retrieved."}

USER MESSAGE: "{state.user_message}"

INSTRUCTIONS:
1. Answer the user's question directly and conversationally
2. Use the knowledge base to provide accurate information
3. If asking about a specific property, provide detailed analysis
4. If information is missing, ask clarifying questions
5. Explain zoning concepts in simple terms
6. Be friendly and helpful, not robotic
7. Keep responses concise (2-4 paragraphs)
8. If you don't have enough information, say so honestly

TONE:
- Conversational and friendly
- Clear and concise
- Helpful and proactive
- Use examples when helpful
- Avoid jargon unless explained

Respond naturally as ZoneWise AI:
"""
        
        # ========================================
        # 3. GENERATE RESPONSE
        # ========================================
        
        logger.info("calling_gemini_for_response")
        
        response = model.generate_content(
            prompt,
            generation_config=genai.GenerationConfig(
                temperature=settings.RESPONSE_TEMPERATURE,
                max_output_tokens=settings.RESPONSE_MAX_TOKENS,
            )
        )
        
        response_text = response.text.strip()
        
        logger.info("response_generated", length=len(response_text))
        
        # ========================================
        # 4. GENERATE FOLLOW-UP SUGGESTIONS
        # ========================================
        
        suggestions = generate_suggestions(state, response_text)
        
        logger.info("suggestions_generated", count=len(suggestions))
        
        # ========================================
        # 5. CALCULATE CONFIDENCE
        # ========================================
        
        # Confidence based on:
        # - Intent confidence
        # - Knowledge retrieval confidence
        # - Presence of specific data
        
        confidence_factors = [
            state.intent_confidence or 0.5,
            state.confidence or 0.5,  # Knowledge retrieval confidence
            0.9 if state.zoning_data else 0.6,  # Have specific zoning data?
            0.9 if state.entities.get("address") else 0.7,  # Have specific address?
        ]
        
        final_confidence = sum(confidence_factors) / len(confidence_factors)
        
        logger.info(
            "response_complete",
            confidence=final_confidence,
            suggestion_count=len(suggestions)
        )
        
        return {
            "response": response_text,
            "suggestions": suggestions,
            "confidence": final_confidence,
            "model_used": settings.PRIMARY_MODEL
        }
        
    except Exception as e:
        logger.error("response_generation_error", error=str(e))
        
        # Fallback response
        return {
            "response": (
                "I apologize, but I'm having trouble generating a response right now. "
                "Could you please rephrase your question or try again?"
            ),
            "suggestions": [
                "Try rephrasing your question",
                "Ask about a specific property address",
                "Learn about zoning basics"
            ],
            "confidence": 0.3,
            "error": str(e)
        }


def generate_suggestions(state: ChatbotState, response: str) -> list[str]:
    """
    Generate contextual follow-up suggestions based on intent and entities
    
    Args:
        state: Current chatbot state
        response: Generated response text
        
    Returns:
        List of 3-5 follow-up suggestions
    """
    suggestions = []
    intent = state.intent
    entities = state.entities
    
    # Intent-specific suggestions
    if intent == "feasibility":
        if entities.get("address"):
            suggestions.append("Calculate maximum buildable square footage")
            suggestions.append("View parking requirements")
            suggestions.append("Generate detailed PDF report")
            suggestions.append("Show property on map")
        else:
            suggestions.append("Provide a property address for detailed analysis")
            suggestions.append("Browse properties by zoning type")
            suggestions.append("Learn about zoning districts")
    
    elif intent == "calculation":
        suggestions.append("View setback diagram")
        suggestions.append("Check height restrictions")
        suggestions.append("Calculate parking spaces needed")
        suggestions.append("Generate development report")
    
    elif intent == "comparison":
        suggestions.append("View detailed comparison table")
        suggestions.append("See zoning map")
        suggestions.append("Learn about specific district")
    
    elif intent == "process":
        suggestions.append("View step-by-step guide")
        suggestions.append("Find contact information")
        suggestions.append("Check timeline and fees")
        suggestions.append("Download application forms")
    
    elif intent == "research":
        suggestions.append("Refine search criteria")
        suggestions.append("View results on map")
        suggestions.append("Save search for alerts")
    
    elif intent == "definition":
        suggestions.append("Learn about related concepts")
        suggestions.append("See real-world examples")
        suggestions.append("Ask another question")
    
    # Generic suggestions (always available)
    suggestions.append("Start a new property analysis")
    
    # Return max 5 suggestions
    return suggestions[:5]
