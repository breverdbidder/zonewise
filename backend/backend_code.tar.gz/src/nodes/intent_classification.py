"""
Intent Classification Node
Classifies user intent using Gemini 2.5 Flash
"""

import json
import google.generativeai as genai
from typing import Dict, Any
import structlog

from src.models import ChatbotState, IntentClassificationResult
from config.settings import settings, INTENT_TYPES

logger = structlog.get_logger()

# Configure Gemini
genai.configure(api_key=settings.GEMINI_API_KEY)
model = genai.GenerativeModel(settings.PRIMARY_MODEL)


async def classify_intent_node(state: ChatbotState) -> Dict[str, Any]:
    """
    Classify user intent into one of 6 categories
    
    Args:
        state: Current chatbot state
        
    Returns:
        Updated state with intent and confidence
    """
    logger.info("intent_classification_start", message=state.user_message)
    
    try:
        # Build prompt with intent types and examples
        prompt = f"""
You are an intent classifier for ZoneWise, a zoning AI assistant.

Classify the user's message into ONE of these intent categories:

{json.dumps(INTENT_TYPES, indent=2)}

User message: "{state.user_message}"

Respond with ONLY valid JSON (no markdown, no extra text):
{{
    "intent": "intent_name",
    "confidence": 0.0-1.0,
    "reasoning": "brief explanation"
}}
"""
        
        # Generate with low temperature for classification
        response = model.generate_content(
            prompt,
            generation_config=genai.GenerationConfig(
                temperature=0.1,  # Low for classification
                max_output_tokens=200,
            )
        )
        
        # Parse JSON response
        response_text = response.text.strip()
        
        # Remove markdown code blocks if present
        if response_text.startswith("```"):
            response_text = response_text.split("```")[1]
            if response_text.startswith("json"):
                response_text = response_text[4:]
            response_text = response_text.strip()
        
        result = json.loads(response_text)
        
        intent = result["intent"]
        confidence = float(result["confidence"])
        reasoning = result.get("reasoning", "")
        
        logger.info(
            "intent_classified",
            intent=intent,
            confidence=confidence,
            reasoning=reasoning
        )
        
        # Update state
        return {
            "intent": intent,
            "intent_confidence": confidence,
            "model_used": settings.PRIMARY_MODEL
        }
        
    except json.JSONDecodeError as e:
        logger.error("intent_json_parse_error", error=str(e), response=response_text)
        
        # Fallback: simple keyword matching
        message_lower = state.user_message.lower()
        
        if any(word in message_lower for word in ["can i", "is it allowed", "permitted", "legal"]):
            intent = "feasibility"
            confidence = 0.6
        elif any(word in message_lower for word in ["how much", "maximum", "calculate", "size"]):
            intent = "calculation"
            confidence = 0.6
        elif any(word in message_lower for word in ["difference", "compare", "vs", "versus"]):
            intent = "comparison"
            confidence = 0.6
        elif any(word in message_lower for word in ["process", "how do i", "steps", "apply"]):
            intent = "process"
            confidence = 0.6
        elif any(word in message_lower for word in ["find", "show me", "search", "list"]):
            intent = "research"
            confidence = 0.6
        elif any(word in message_lower for word in ["what is", "what does", "define", "meaning"]):
            intent = "definition"
            confidence = 0.6
        else:
            intent = "feasibility"  # Default
            confidence = 0.5
        
        logger.info("intent_fallback_keyword_match", intent=intent, confidence=confidence)
        
        return {
            "intent": intent,
            "intent_confidence": confidence,
            "model_used": "keyword_fallback"
        }
        
    except Exception as e:
        logger.error("intent_classification_error", error=str(e))
        
        # Fallback to default
        return {
            "intent": "feasibility",
            "intent_confidence": 0.5,
            "error": str(e),
            "model_used": "error_fallback"
        }
