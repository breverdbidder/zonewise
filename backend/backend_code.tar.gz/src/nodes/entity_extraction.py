"""
Entity Extraction Node
Extracts structured entities from user messages using regex and NER
"""

import re
from typing import Dict, Any
from fuzzywuzzy import fuzz
import structlog

from src.models import ChatbotState
from config.settings import settings, ENTITY_TYPES

logger = structlog.get_logger()


async def extract_entities_node(state: ChatbotState) -> Dict[str, Any]:
    """
    Extract entities from user message
    
    Entities:
    - address (property location)
    - zoning_code (R-1, C-2, etc.)
    - use_type (apartments, duplex, etc.)
    - location (city name)
    - quantity (SF, units, etc.)
    
    Args:
        state: Current chatbot state
        
    Returns:
        Updated state with entities and confidence scores
    """
    logger.info("entity_extraction_start", message=state.user_message)
    
    entities = {}
    confidence = {}
    
    user_message = state.user_message
    
    # ========================================
    # 1. EXTRACT ADDRESS
    # ========================================
    for pattern in ENTITY_TYPES["address"]["regex"]:
        match = re.search(pattern, user_message, re.IGNORECASE)
        if match:
            entities["address"] = match.group().strip()
            confidence["address"] = 0.9
            logger.info("entity_extracted_address", address=entities["address"])
            break
    
    # ========================================
    # 2. EXTRACT ZONING CODE
    # ========================================
    for pattern in ENTITY_TYPES["zoning_code"]["regex"]:
        match = re.search(pattern, user_message, re.IGNORECASE)
        if match:
            entities["zoning_code"] = match.group().upper().strip()
            confidence["zoning_code"] = 0.95
            logger.info("entity_extracted_zoning", zoning=entities["zoning_code"])
            break
    
    # ========================================
    # 3. EXTRACT USE TYPE (keyword matching)
    # ========================================
    message_lower = user_message.lower()
    
    for use_category, keywords in ENTITY_TYPES["use_type"]["keywords"].items():
        for keyword in keywords:
            if keyword.lower() in message_lower:
                entities["use_type"] = keyword
                entities["use_category"] = use_category
                confidence["use_type"] = 0.85
                logger.info(
                    "entity_extracted_use",
                    use_type=keyword,
                    category=use_category
                )
                break
        if "use_type" in entities:
            break
    
    # ========================================
    # 4. EXTRACT LOCATION (fuzzy city matching)
    # ========================================
    for city in settings.BREVARD_JURISDICTIONS:
        # Exact match
        if city.lower() in message_lower:
            entities["location"] = city
            confidence["location"] = 1.0
            logger.info("entity_extracted_location_exact", location=city)
            break
        
        # Fuzzy match (for misspellings like "Melborn")
        # Use partial ratio to handle "in Melbourne" or "Melbourne area"
        similarity = fuzz.partial_ratio(city.lower(), message_lower)
        if similarity > 90:  # 90%+ similarity
            entities["location"] = city
            confidence["location"] = similarity / 100.0
            logger.info(
                "entity_extracted_location_fuzzy",
                location=city,
                similarity=similarity
            )
            break
    
    # ========================================
    # 5. EXTRACT QUANTITY (SF, units, acres)
    # ========================================
    for pattern in ENTITY_TYPES["quantity"]["regex"]:
        match = re.search(pattern, user_message, re.IGNORECASE)
        if match:
            entities["quantity"] = match.group().strip()
            confidence["quantity"] = 0.9
            logger.info("entity_extracted_quantity", quantity=entities["quantity"])
            break
    
    # ========================================
    # 6. USE CONTEXT IF ENTITIES MISSING
    # ========================================
    
    # If no address found but we have current property in context
    if "address" not in entities and state.current_property:
        entities["address"] = state.current_property.get("address")
        confidence["address"] = 0.7  # Lower confidence (from context)
        logger.info("entity_from_context_address", address=entities["address"])
    
    # If no zoning found but we have current property in context
    if "zoning_code" not in entities and state.current_property:
        entities["zoning_code"] = state.current_property.get("zoning")
        confidence["zoning_code"] = 0.7
        logger.info("entity_from_context_zoning", zoning=entities["zoning_code"])
    
    # If no location found, default to Melbourne (most common)
    if "location" not in entities:
        entities["location"] = settings.DEFAULT_JURISDICTION
        confidence["location"] = 0.5  # Low confidence (default)
        logger.info("entity_default_location", location=entities["location"])
    
    # ========================================
    # 7. CALCULATE OVERALL CONFIDENCE
    # ========================================
    
    if confidence:
        overall_confidence = sum(confidence.values()) / len(confidence)
    else:
        overall_confidence = 0.3  # Low confidence if no entities
    
    logger.info(
        "entity_extraction_complete",
        entities=entities,
        confidence=confidence,
        overall=overall_confidence
    )
    
    return {
        "entities": entities,
        "entity_confidence": confidence,
    }


# Utility function to parse lot size
def parse_lot_size(quantity_str: str) -> int:
    """
    Parse lot size from string like "10,000 SF" or "0.5 acres"
    Returns square feet as integer
    """
    quantity_str = quantity_str.upper().strip()
    
    # Extract number
    match = re.search(r'([\d,]+(?:\.\d+)?)', quantity_str)
    if not match:
        return 0
    
    num_str = match.group(1).replace(',', '')
    num = float(num_str)
    
    # Convert to SF
    if 'ACRE' in quantity_str:
        return int(num * 43560)  # 1 acre = 43,560 SF
    else:
        return int(num)  # Assume SF


# Utility function to parse unit count
def parse_unit_count(quantity_str: str) -> int:
    """
    Parse unit count from string like "4 units"
    Returns integer
    """
    match = re.search(r'(\d+)', quantity_str)
    if match:
        return int(match.group(1))
    return 0
