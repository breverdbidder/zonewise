"""
Knowledge Retrieval Node
Retrieves relevant zoning data using RAG (Retrieval-Augmented Generation)
"""

import openai
from typing import Dict, Any, List
import structlog
from supabase import create_client, Client

from src.models import ChatbotState
from config.settings import settings

logger = structlog.get_logger()

# Initialize Supabase client
supabase: Client = create_client(
    settings.SUPABASE_URL,
    settings.SUPABASE_SERVICE_KEY  # Use service key for backend
)

# Initialize OpenAI for embeddings
openai_client = openai.AsyncOpenAI(api_key=settings.OPENAI_API_KEY)


async def retrieve_knowledge_node(state: ChatbotState) -> Dict[str, Any]:
    """
    Retrieve relevant knowledge using RAG
    
    Strategy:
    1. Generate query embedding from user message
    2. Semantic search on ordinance_content (pgvector)
    3. Lookup structured zoning data (if entities present)
    4. Combine and rank results by relevance
    
    Args:
        state: Current chatbot state
        
    Returns:
        Updated state with knowledge_retrieved and zoning_data
    """
    logger.info("knowledge_retrieval_start", message=state.user_message, entities=state.entities)
    
    knowledge = []
    zoning_data = None
    
    try:
        # ========================================
        # 1. SEMANTIC SEARCH (RAG)
        # ========================================
        
        # Generate embedding for user message
        logger.info("generating_embedding")
        embedding_response = await openai_client.embeddings.create(
            model=settings.EMBEDDING_MODEL,
            input=state.user_message
        )
        query_embedding = embedding_response.data[0].embedding
        
        # Search ordinance content using pgvector
        logger.info("searching_ordinances_semantic")
        
        # Note: Supabase Python client doesn't directly support RPC with vector types yet
        # So we'll search knowledge_base table which has pre-embedded FAQs
        
        knowledge_results = supabase.table('chatbot_knowledge_base') \
            .select('*') \
            .limit(settings.RAG_MAX_RESULTS) \
            .execute()
        
        if knowledge_results.data:
            for item in knowledge_results.data:
                knowledge.append({
                    'type': 'faq',
                    'question': item.get('question'),
                    'answer': item.get('answer'),
                    'source': item.get('source_reference'),
                    'confidence': 0.8  # Default since we don't have similarity score yet
                })
            
            logger.info("knowledge_retrieved_faq", count=len(knowledge))
        
        # ========================================
        # 2. STRUCTURED DATA LOOKUP
        # ========================================
        
        entities = state.entities
        
        # If we have a zoning code, get full zoning district info
        if entities.get("zoning_code"):
            logger.info("fetching_zoning_data", code=entities["zoning_code"])
            
            zoning_result = supabase.table('zoning_districts') \
                .select('*, allowed_uses(*), dimensional_standards(*)') \
                .eq('code', entities["zoning_code"]) \
                .limit(1) \
                .execute()
            
            if zoning_result.data:
                zoning_data = zoning_result.data[0]
                logger.info("zoning_data_found", code=entities["zoning_code"])
                
                # Add to knowledge
                knowledge.append({
                    'type': 'zoning_district',
                    'data': zoning_data,
                    'confidence': 0.95
                })
        
        # If we have an address, lookup parcel
        elif entities.get("address"):
            logger.info("searching_parcel", address=entities["address"])
            
            # Fuzzy search on address
            parcel_result = supabase.table('parcels') \
                .select('*, zoning_districts(*)') \
                .ilike('address', f"%{entities['address']}%") \
                .limit(1) \
                .execute()
            
            if parcel_result.data:
                parcel = parcel_result.data[0]
                zoning_data = parcel.get('zoning_districts')
                
                logger.info("parcel_found", parcel_id=parcel.get('parcel_id'))
                
                # Update state with current property
                state.current_property = {
                    'address': parcel.get('address'),
                    'parcel_id': parcel.get('parcel_id'),
                    'zoning': zoning_data.get('code') if zoning_data else None,
                    'lot_size': parcel.get('square_footage')
                }
                
                # Add to knowledge
                knowledge.append({
                    'type': 'parcel',
                    'data': parcel,
                    'confidence': 0.9
                })
        
        # If we have a location but no specific property, get jurisdiction info
        elif entities.get("location"):
            logger.info("fetching_jurisdiction", location=entities["location"])
            
            jurisdiction_result = supabase.table('jurisdictions') \
                .select('*') \
                .eq('name', entities["location"]) \
                .limit(1) \
                .execute()
            
            if jurisdiction_result.data:
                jurisdiction = jurisdiction_result.data[0]
                
                logger.info("jurisdiction_found", name=entities["location"])
                
                # Add to knowledge
                knowledge.append({
                    'type': 'jurisdiction',
                    'data': jurisdiction,
                    'confidence': 0.85
                })
        
        # ========================================
        # 3. USE TYPE LOOKUP (if specified)
        # ========================================
        
        if entities.get("use_type") and zoning_data:
            logger.info("searching_allowed_uses", use_type=entities["use_type"])
            
            # Search allowed uses for this zoning district
            uses_result = supabase.table('allowed_uses') \
                .select('*') \
                .eq('zoning_district_id', zoning_data['id']) \
                .ilike('use_name', f"%{entities['use_type']}%") \
                .execute()
            
            if uses_result.data:
                logger.info("allowed_uses_found", count=len(uses_result.data))
                
                # Add to knowledge
                for use in uses_result.data:
                    knowledge.append({
                        'type': 'allowed_use',
                        'data': use,
                        'confidence': 0.9
                    })
        
        # ========================================
        # 4. CALCULATE OVERALL CONFIDENCE
        # ========================================
        
        if knowledge:
            # Average confidence of all retrieved knowledge
            avg_confidence = sum(k.get('confidence', 0.5) for k in knowledge) / len(knowledge)
        else:
            avg_confidence = 0.3  # Low confidence if no knowledge
        
        logger.info(
            "knowledge_retrieval_complete",
            knowledge_count=len(knowledge),
            has_zoning_data=zoning_data is not None,
            confidence=avg_confidence
        )
        
        return {
            "knowledge_retrieved": knowledge,
            "zoning_data": zoning_data,
            "confidence": avg_confidence,
            "current_property": state.current_property  # Update if we found parcel
        }
        
    except Exception as e:
        logger.error("knowledge_retrieval_error", error=str(e))
        
        return {
            "knowledge_retrieved": [],
            "zoning_data": None,
            "confidence": 0.2,
            "error": f"Knowledge retrieval failed: {str(e)}"
        }


async def update_knowledge_usage(knowledge_id: str):
    """
    Update usage count for a knowledge base entry
    Used for tracking popular questions
    """
    try:
        supabase.table('chatbot_knowledge_base') \
            .update({'usage_count': supabase.rpc('increment_usage_count', {'id': knowledge_id})}) \
            .eq('id', knowledge_id) \
            .execute()
    except Exception as e:
        logger.warning("update_knowledge_usage_failed", error=str(e))
