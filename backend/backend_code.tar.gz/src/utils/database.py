"""
Database Utilities
Functions for interacting with Supabase
"""

from supabase import create_client, Client
from typing import List, Dict, Any, Optional
from uuid import UUID, uuid4
from datetime import datetime
import structlog

from config.settings import settings

logger = structlog.get_logger()

# Initialize Supabase client
supabase: Client = create_client(
    settings.SUPABASE_URL,
    settings.SUPABASE_SERVICE_KEY  # Use service key for backend operations
)


# ============================================================================
# CONVERSATION OPERATIONS
# ============================================================================

async def store_conversation(session_id: str, user_id: Optional[str] = None) -> str:
    """
    Create or get existing conversation
    
    Args:
        session_id: Session identifier
        user_id: Optional authenticated user ID
        
    Returns:
        conversation_id (UUID as string)
    """
    try:
        # Check if conversation exists
        existing = supabase.table('chatbot_conversations') \
            .select('id') \
            .eq('session_id', session_id) \
            .execute()
        
        if existing.data:
            conversation_id = existing.data[0]['id']
            logger.info("conversation_exists", id=conversation_id)
            return conversation_id
        
        # Create new conversation
        result = supabase.table('chatbot_conversations').insert({
            'session_id': session_id,
            'user_id': user_id,
            'started_at': datetime.utcnow().isoformat(),
            'last_message_at': datetime.utcnow().isoformat(),
            'message_count': 0,
            'conversation_status': 'active'
        }).execute()
        
        conversation_id = result.data[0]['id']
        logger.info("conversation_created", id=conversation_id)
        
        return conversation_id
        
    except Exception as e:
        logger.error("conversation_store_error", error=str(e))
        raise


async def update_conversation_stats(conversation_id: str):
    """
    Update conversation statistics (message count, last message time)
    
    Args:
        conversation_id: Conversation UUID
    """
    try:
        # Count messages
        messages = supabase.table('chatbot_messages') \
            .select('id', count='exact') \
            .eq('conversation_id', conversation_id) \
            .execute()
        
        message_count = messages.count or 0
        
        # Update conversation
        supabase.table('chatbot_conversations').update({
            'message_count': message_count,
            'last_message_at': datetime.utcnow().isoformat()
        }).eq('id', conversation_id).execute()
        
        logger.info("conversation_stats_updated", id=conversation_id, count=message_count)
        
    except Exception as e:
        logger.error("conversation_stats_error", error=str(e))


async def get_conversation_history(
    session_id: str,
    limit: int = 10
) -> List[Dict[str, str]]:
    """
    Get conversation history
    
    Args:
        session_id: Session identifier
        limit: Max messages to return (default 10)
        
    Returns:
        List of messages [{role, content}, ...]
    """
    try:
        # Get conversation ID
        conv = supabase.table('chatbot_conversations') \
            .select('id') \
            .eq('session_id', session_id) \
            .execute()
        
        if not conv.data:
            return []
        
        conversation_id = conv.data[0]['id']
        
        # Get messages
        messages = supabase.table('chatbot_messages') \
            .select('role, content, created_at') \
            .eq('conversation_id', conversation_id) \
            .order('created_at', desc=False) \
            .limit(limit) \
            .execute()
        
        history = [
            {
                'role': msg['role'],
                'content': msg['content']
            }
            for msg in messages.data
        ]
        
        logger.info("conversation_history_retrieved", count=len(history))
        
        return history
        
    except Exception as e:
        logger.error("conversation_history_error", error=str(e))
        return []


# ============================================================================
# MESSAGE OPERATIONS
# ============================================================================

async def store_message(
    conversation_id: str,
    role: str,
    content: str,
    intent: Optional[str] = None,
    entities: Optional[Dict[str, Any]] = None,
    response_time_ms: Optional[int] = None,
    confidence: Optional[float] = None
) -> str:
    """
    Store a message in the conversation
    
    Args:
        conversation_id: Parent conversation UUID
        role: 'user' or 'assistant'
        content: Message text
        intent: Classified intent (assistant only)
        entities: Extracted entities
        response_time_ms: Response time (assistant only)
        confidence: Confidence score (assistant only)
        
    Returns:
        message_id (UUID as string)
    """
    try:
        result = supabase.table('chatbot_messages').insert({
            'conversation_id': conversation_id,
            'role': role,
            'content': content,
            'intent': intent,
            'entities': entities,
            'response_time_ms': response_time_ms,
            'confidence_score': confidence,
            'created_at': datetime.utcnow().isoformat()
        }).execute()
        
        message_id = result.data[0]['id']
        logger.info("message_stored", id=message_id, role=role)
        
        return message_id
        
    except Exception as e:
        logger.error("message_store_error", error=str(e))
        raise


# ============================================================================
# FEEDBACK OPERATIONS
# ============================================================================

async def store_feedback(
    session_id: str,
    message_id: str,
    feedback_type: str,
    feedback_text: Optional[str] = None,
    user_id: Optional[str] = None
):
    """
    Store user feedback
    
    Args:
        session_id: Session identifier
        message_id: Message UUID
        feedback_type: thumbs_up, thumbs_down, report, suggestion
        feedback_text: Optional detailed feedback
        user_id: Optional authenticated user ID
    """
    try:
        # Get conversation ID
        conv = supabase.table('chatbot_conversations') \
            .select('id') \
            .eq('session_id', session_id) \
            .execute()
        
        conversation_id = conv.data[0]['id'] if conv.data else None
        
        # Store feedback
        supabase.table('chatbot_feedback').insert({
            'message_id': message_id,
            'conversation_id': conversation_id,
            'feedback_type': feedback_type,
            'feedback_text': feedback_text,
            'user_id': user_id,
            'reviewed': False,
            'created_at': datetime.utcnow().isoformat()
        }).execute()
        
        # Update message thumbs up/down
        if feedback_type == 'thumbs_up':
            supabase.table('chatbot_messages').update({
                'thumbs_up': True
            }).eq('id', message_id).execute()
        
        elif feedback_type == 'thumbs_down':
            supabase.table('chatbot_messages').update({
                'thumbs_down': True
            }).eq('id', message_id).execute()
        
        logger.info("feedback_stored", type=feedback_type, message=message_id)
        
    except Exception as e:
        logger.error("feedback_store_error", error=str(e))
        raise


# ============================================================================
# ANALYTICS OPERATIONS
# ============================================================================

async def log_daily_metrics():
    """
    Calculate and store daily chatbot metrics
    
    Should be run once per day (scheduled job)
    """
    try:
        today = datetime.utcnow().date()
        
        # Total conversations today
        conversations = supabase.table('chatbot_conversations') \
            .select('id', count='exact') \
            .gte('started_at', today.isoformat()) \
            .execute()
        
        total_conversations = conversations.count or 0
        
        # Total messages today
        messages = supabase.table('chatbot_messages') \
            .select('id', count='exact') \
            .gte('created_at', today.isoformat()) \
            .execute()
        
        total_messages = messages.count or 0
        
        # Average messages per conversation
        avg_messages = total_messages / total_conversations if total_conversations > 0 else 0
        
        # Average response time
        assistant_messages = supabase.table('chatbot_messages') \
            .select('response_time_ms') \
            .eq('role', 'assistant') \
            .gte('created_at', today.isoformat()) \
            .execute()
        
        response_times = [m['response_time_ms'] for m in assistant_messages.data if m['response_time_ms']]
        avg_response_time = sum(response_times) / len(response_times) if response_times else 0
        
        # Thumbs up/down counts
        thumbs_up = supabase.table('chatbot_messages') \
            .select('id', count='exact') \
            .eq('thumbs_up', True) \
            .gte('created_at', today.isoformat()) \
            .execute()
        
        thumbs_down = supabase.table('chatbot_messages') \
            .select('id', count='exact') \
            .eq('thumbs_down', True) \
            .gte('created_at', today.isoformat()) \
            .execute()
        
        thumbs_up_count = thumbs_up.count or 0
        thumbs_down_count = thumbs_down.count or 0
        
        # Satisfaction score
        total_feedback = thumbs_up_count + thumbs_down_count
        satisfaction = thumbs_up_count / total_feedback if total_feedback > 0 else 0
        
        # Store metrics
        supabase.table('chatbot_daily_metrics').insert({
            'date': today.isoformat(),
            'total_conversations': total_conversations,
            'total_messages': total_messages,
            'avg_messages_per_conversation': round(avg_messages, 2),
            'avg_response_time_ms': int(avg_response_time),
            'thumbs_up_count': thumbs_up_count,
            'thumbs_down_count': thumbs_down_count,
            'satisfaction_score': round(satisfaction, 2),
            'created_at': datetime.utcnow().isoformat()
        }).execute()
        
        logger.info(
            "daily_metrics_logged",
            date=today,
            conversations=total_conversations,
            messages=total_messages
        )
        
    except Exception as e:
        logger.error("daily_metrics_error", error=str(e))


# ============================================================================
# INTENT & ENTITY TRACKING
# ============================================================================

async def log_intent_classification(
    user_query: str,
    classified_intent: str,
    confidence: float,
    message_id: Optional[str] = None
):
    """Log intent classification for ML improvement"""
    try:
        supabase.table('chatbot_intents').insert({
            'intent_type': classified_intent,
            'user_query': user_query,
            'classified_intent': classified_intent,
            'confidence': confidence,
            'message_id': message_id,
            'created_at': datetime.utcnow().isoformat()
        }).execute()
        
        logger.info("intent_logged", intent=classified_intent)
        
    except Exception as e:
        logger.error("intent_log_error", error=str(e))


async def log_entity_extraction(
    message_id: str,
    entity_type: str,
    entity_value: str,
    confidence: float
):
    """Log entity extraction for ML improvement"""
    try:
        supabase.table('chatbot_entities').insert({
            'message_id': message_id,
            'entity_type': entity_type,
            'entity_value': entity_value,
            'confidence': confidence,
            'created_at': datetime.utcnow().isoformat()
        }).execute()
        
        logger.info("entity_logged", type=entity_type, value=entity_value)
        
    except Exception as e:
        logger.error("entity_log_error", error=str(e))
