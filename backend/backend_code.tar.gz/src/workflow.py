"""
ZoneWise Chatbot Workflow
LangGraph orchestration connecting all nodes
"""

from langgraph.graph import StateGraph, END
from typing import Dict, Any
import structlog
import time

from src.models import ChatbotState
from src.nodes.intent_classification import classify_intent_node
from src.nodes.entity_extraction import extract_entities_node
from src.nodes.knowledge_retrieval import retrieve_knowledge_node
from src.nodes.response_generation import generate_response_node
from config.settings import settings

logger = structlog.get_logger()


# ============================================================================
# QUALITY CHECK NODE
# ============================================================================

async def quality_check_node(state: ChatbotState) -> Dict[str, Any]:
    """
    Quality check: Verify response meets confidence threshold
    
    If confidence < threshold:
    - Log for human review
    - Add disclaimer to response
    
    Args:
        state: Current chatbot state
        
    Returns:
        Updated state (possibly with disclaimer)
    """
    logger.info("quality_check", confidence=state.confidence)
    
    if state.confidence and state.confidence < settings.INTENT_CONFIDENCE_THRESHOLD:
        logger.warning(
            "low_confidence_response",
            confidence=state.confidence,
            intent=state.intent
        )
        
        # Add disclaimer
        disclaimer = "\n\n*Note: I'm not entirely certain about this answer. Please verify with local planning authorities or consult a professional.*"
        
        if state.response:
            state.response += disclaimer
        
        return {"response": state.response}
    
    return {}


# ============================================================================
# CONDITIONAL EDGE FUNCTION
# ============================================================================

def should_regenerate(state: ChatbotState) -> str:
    """
    Decide if response should be regenerated
    
    Regenerate if:
    - Confidence < 0.5 (very low)
    - Response is too short (<50 chars)
    - Error occurred
    
    Args:
        state: Current chatbot state
        
    Returns:
        "regenerate" or "complete"
    """
    if state.error:
        logger.warning("response_has_error", error=state.error)
        return "regenerate" if state.confidence and state.confidence > 0.3 else "complete"
    
    if state.confidence and state.confidence < 0.5:
        logger.warning("confidence_too_low", confidence=state.confidence)
        # Only regenerate once (check if already regenerated)
        if state.model_used != "regenerated":
            return "regenerate"
    
    if state.response and len(state.response) < 50:
        logger.warning("response_too_short", length=len(state.response))
        return "regenerate"
    
    return "complete"


# ============================================================================
# BUILD WORKFLOW
# ============================================================================

def build_chatbot_workflow() -> StateGraph:
    """
    Build the LangGraph chatbot workflow
    
    Flow:
    1. Classify Intent → 2. Extract Entities → 3. Retrieve Knowledge → 
    4. Generate Response → 5. Quality Check → (Regenerate if needed) → END
    
    Returns:
        Compiled StateGraph workflow
    """
    logger.info("building_chatbot_workflow")
    
    # Create state graph
    workflow = StateGraph(ChatbotState)
    
    # Add nodes
    workflow.add_node("classify_intent", classify_intent_node)
    workflow.add_node("extract_entities", extract_entities_node)
    workflow.add_node("retrieve_knowledge", retrieve_knowledge_node)
    workflow.add_node("generate_response", generate_response_node)
    workflow.add_node("quality_check", quality_check_node)
    
    # Define flow
    workflow.set_entry_point("classify_intent")
    
    workflow.add_edge("classify_intent", "extract_entities")
    workflow.add_edge("extract_entities", "retrieve_knowledge")
    workflow.add_edge("retrieve_knowledge", "generate_response")
    workflow.add_edge("generate_response", "quality_check")
    
    # Conditional edge after quality check
    workflow.add_conditional_edges(
        "quality_check",
        should_regenerate,
        {
            "regenerate": "generate_response",  # Try generating again
            "complete": END
        }
    )
    
    # Compile
    app = workflow.compile()
    
    logger.info("chatbot_workflow_built")
    
    return app


# ============================================================================
# CHATBOT EXECUTION FUNCTION
# ============================================================================

async def run_chatbot(
    user_message: str,
    session_id: str,
    conversation_history: list[Dict[str, str]] = None,
    current_property: Dict[str, Any] = None
) -> Dict[str, Any]:
    """
    Execute chatbot workflow
    
    Args:
        user_message: User's input message
        session_id: Conversation session ID
        conversation_history: Previous messages (optional)
        current_property: Current property context (optional)
        
    Returns:
        Complete response dictionary with:
        - response (str)
        - suggestions (list)
        - confidence (float)
        - intent (str)
        - entities (dict)
        - response_time_ms (int)
    """
    logger.info("chatbot_execution_start", message=user_message, session=session_id)
    
    start_time = time.time()
    
    try:
        # Build workflow
        app = build_chatbot_workflow()
        
        # Create initial state
        initial_state = ChatbotState(
            user_message=user_message,
            session_id=session_id,
            conversation_history=conversation_history or [],
            current_property=current_property
        )
        
        # Run workflow
        logger.info("executing_workflow")
        final_state = await app.ainvoke(initial_state)
        
        # Calculate response time
        response_time_ms = int((time.time() - start_time) * 1000)
        
        logger.info(
            "chatbot_execution_complete",
            response_time_ms=response_time_ms,
            confidence=final_state.confidence
        )
        
        # Return result
        return {
            "response": final_state.response,
            "suggestions": final_state.suggestions,
            "confidence": final_state.confidence,
            "intent": final_state.intent,
            "entities": final_state.entities,
            "response_time_ms": response_time_ms,
            "session_id": session_id,
            "model_used": final_state.model_used,
            "error": final_state.error
        }
        
    except Exception as e:
        logger.error("chatbot_execution_error", error=str(e))
        
        response_time_ms = int((time.time() - start_time) * 1000)
        
        return {
            "response": (
                "I apologize, but I encountered an error processing your message. "
                "Please try rephrasing your question or contact support if the issue persists."
            ),
            "suggestions": [
                "Try rephrasing your question",
                "Ask a different question",
                "Contact support"
            ],
            "confidence": 0.2,
            "intent": None,
            "entities": {},
            "response_time_ms": response_time_ms,
            "session_id": session_id,
            "error": str(e)
        }


# ============================================================================
# EXAMPLE USAGE
# ============================================================================

if __name__ == "__main__":
    import asyncio
    
    async def test_chatbot():
        """Test chatbot with sample messages"""
        
        print("=" * 80)
        print("ZoneWise AI Chatbot - Test Mode")
        print("=" * 80)
        print()
        
        test_messages = [
            "Can I build apartments in Melbourne?",
            "What does FAR mean?",
            "What's the difference between R-1 and R-2 zoning?"
        ]
        
        for msg in test_messages:
            print(f"\n🧑 USER: {msg}")
            print("-" * 80)
            
            result = await run_chatbot(
                user_message=msg,
                session_id="test_session_123"
            )
            
            print(f"\n🤖 ZONEWISE: {result['response']}")
            print(f"\n📊 Metadata:")
            print(f"   Intent: {result['intent']}")
            print(f"   Confidence: {result['confidence']:.2f}")
            print(f"   Response Time: {result['response_time_ms']}ms")
            print(f"   Entities: {result['entities']}")
            
            if result['suggestions']:
                print(f"\n💡 Suggestions:")
                for i, sug in enumerate(result['suggestions'], 1):
                    print(f"   {i}. {sug}")
            
            print("\n" + "=" * 80)
    
    # Run test
    asyncio.run(test_chatbot())
